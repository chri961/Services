<?php
/**
 * The index-blog sidebar template file.
 * @package TimeTurner
 * @since TimeTurner 1.0.0
*/
?>
<div id="sidebar">
<?php if ( dynamic_sidebar( 'sidebar-1' ) ) : else : ?>
<?php endif; ?>
</div> <!-- end of sidebar -->